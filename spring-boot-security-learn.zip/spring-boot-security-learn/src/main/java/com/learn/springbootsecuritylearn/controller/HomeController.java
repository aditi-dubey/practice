package com.learn.springbootsecuritylearn.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HomeController {
	
	@GetMapping("/home")
	public String getHome() {
		return "This is home page";
	}
	
	@GetMapping("/login")
	public String getLogin() {
		return "This is login method";
	}
	
	@GetMapping("/register")
	public String getRegister() {
		return "This is register method";
	}
}
